//Samreen Islam sfi6zy 4/18/17 Lab102 huffNode.cpp

#include <iostream>
#include "huffNode.h"

using namespace std;

huffNode::huffNode() {
  ascii = '\0';
  freq=0;
  left=NULL;
  right=NULL;
}

huffNode::huffNode(char c, int f) {
  ascii=c;
  freq=f;
  left=NULL;
  right=NULL;
}

huffNode::~huffNode(){
  delete left;
  delete right;
}
