//Samreen Islam sfi6zy Lab102 4/18/17 huffmanenc.cpp

#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include "binary_heap.h"
#include <vector>
#include <string>

using namespace std;

binary_heap compress(binary_heap heap);
void makePrefix(huffNode* h, string prefix, int dir, vector<string> &v);

int main (int argc, char **argv) {
    // verify the correct number of parameters
    if ( argc != 2 ) {
        cout << "Must supply the input file name as the one and only parameter" << endl;
        exit(1);
    }
    // attempt to open the supplied file.  FILE is a type desgined to
    // hold file pointers.  The first parameter to fopen() is the
    // filename.  The second parameter is the mode -- "r" means it
    // will read from the file.
    FILE *fp = fopen(argv[1], "r");
    // if the file wasn't found, output and error message and exit
    if ( fp == NULL ) {
        cout << "File '" << argv[1] << "' does not exist!" << endl;
        exit(2);
    }
    // read in each character, one by one.  Note that the fgetc() will
    // read in a single character from a file, and returns EOF when it
    // reaches the end of a file.
    char g;
    vector<int> freq (128);
    while ( (g = fgetc(fp)) != EOF ){
      freq[(int)g]++;
    }
    int num_symbols = 0;
    binary_heap minheap;
    for (int i = 32; i < freq.size(); i++) {
      if(freq[i] > 0) {
	huffNode* huffChar = new huffNode((char)i,freq[i]);
      	minheap.insert(huffChar);
	  }
    }
    num_symbols = minheap.size();
    binary_heap compressed = compress(minheap);
    vector<string> prefixes(128);
    makePrefix(compressed.findMin(),"",2, prefixes);
    /*   for (int i = 32; i < prefixes.size(); i++) {
      if(prefixes[i] != "") {
	cout << (char) i << ":" << prefixes[i] << endl;
      }
      }*/
    // a nice pretty separator
       cout << "----------------------------------------" << endl;
    // rewinds the file pointer, so that it starts reading the file
    // again from the begnning
    rewind(fp);
    // read the file again, and print to the screen
    int compd_bits = 0;
    while ( (g = fgetc(fp)) != EOF ) {
      compd_bits += prefixes[(int)g].size();
      cout << prefixes[(int)g] << " ";
    }
    cout << endl;
    // close the file
    fclose(fp);
    cout << "----------------------------------------" << endl;
    int tot_symbols = compressed.findMin()->freq;
    cout << "There are a total of " << tot_symbols << " symbols that are encoded." << endl;
    cout << "There are " << num_symbols << " distinct symbols used." << endl;
    cout << "There were " << tot_symbols*8 << " bits in the original file." << endl;
    cout << "There were " << compd_bits << " bits in the compressed file." << endl;
    cout << "This gives a compression ratio of " << (tot_symbols*8)/(double) compd_bits << "." << endl;
    cout << "The cost of the Huffman tree is " << compd_bits/(double) tot_symbols << " bits per character." << endl;
    
}

binary_heap compress(binary_heap heap) {
  while(heap.size() > 1) {
  huffNode* fake = new huffNode;
  fake->left = heap.deleteMin();
  fake->right = heap.deleteMin();
  fake->freq = (fake->left->freq)+(fake->right->freq);
  heap.insert(fake);
  }
  return heap;
}

void makePrefix(huffNode* h, string prefix, int dir, vector<string> &v) {
  if (dir == 0) {//left
    prefix += "0";
  }else if (dir == 1){//right
    prefix += "1";
  }
   if (h->left ==NULL && h->right ==NULL) {
     if (h->ascii == ' ') {
        cout << "space " << prefix << endl;
     } else {
    cout << h->ascii << " " << prefix << endl;
     }
    v[(int)(h->ascii)]=prefix;
  }
  if (h->left != NULL) {
    makePrefix(h->left, prefix, 0, v);
  } 
  if (h->right != NULL) {
    makePrefix(h->right, prefix, 1, v);
  }
  }

  

    

	    
