//Samreen Islam sfi6zy Lab102 4/19/17 huffmandec.cpp
// This program is the skeleton code for the lab 10 in-lab.  It uses
// C++ streams for the file input, and just prints out the data when
// read in from the file.

#include <iostream>
#include <fstream>
#include <sstream>
#include <stdlib.h>
#include "huffNode.h"
#include <vector>
#include <string>
#include <cstring>
#include <alloca.h>
using namespace std;

void makeTree(huffNode* h, string prefix, vector<string> &pfs, int dir);

// main(): we want to use parameters
int main (int argc, char **argv) {
    // verify the correct number of parameters
    if ( argc != 2 ) {
        cout << "Must supply the input file name as the only parameter" << endl;
        exit(1);
    }
    // attempt to open the supplied file; must be opened in binary
    // mode, as otherwise whitespace is discarded
    ifstream file(argv[1], ifstream::binary);
    // report any problems opening the file and then exit
    if ( !file.is_open() ) {
        cout << "Unable to open file '" << argv[1] << "'." << endl;
        exit(2);
    }
    vector<string> prefixes(128);
    // read in the first section of the file: the prefix codes
    while ( true ) {
        string character, prefix;
        // read in the first token on the line
        file >> character;
        // did we hit the separator?
        if ( (character[0] == '-') && (character.length() > 1) )
            break;
        // check for space
        if ( character == "space" )
            character = " ";
        // read in the prefix code
        file >> prefix;
        // do something with the prefix code
	const char* a = character.c_str();
	int x = (int) *a;
	prefixes[x] = prefix;
	/*   cout << "character '" << character << "' has prefix code '"
             << prefix << "'" << endl; */
    }
    //make huffman tree
    huffNode* huffHead = new huffNode();
    makeTree(huffHead, "", prefixes, 2);
    // read in the second section of the file: the encoded message
    stringstream sstm;
    while ( true ) {
        string bits;
        // read in the next set of 1's and 0's
        file >> bits;
        // check for the separator
        if ( bits[0] == '-' )
            break;
        // add it to the stringstream
	sstm << bits;
    }
    string allbits = sstm.str();
    file.close();
    huffNode* currNode = huffHead;
    for (int i = 0; i < allbits.size()+1; i++) {
      if (currNode->left == NULL && currNode->right == NULL) {
	    cout << currNode->ascii;
	    currNode = huffHead;
	  }
	  if(allbits[i] == '0' && currNode->left != NULL){
	    currNode = currNode->left;
	  } else if (allbits[i] =='1' && currNode->right != NULL) {
	    currNode = currNode->right;
	  }
	}
    cout << endl;
    }

void makeTree(huffNode* h, string prefix, vector<string> &pfs, int dir) {
    if (dir == 0) {//left
    prefix += "0";
    }else if (dir == 1){//right
    prefix += "1";
    }
    for (int i = 32; i < pfs.size(); i++) {
      if (pfs[i] != "") {
	if (prefix == pfs[i]) {
	  h->ascii = (char) i;
          return;
	}
      }
    }
    huffNode *lefty = new huffNode();
    h->left = lefty;
    makeTree(lefty,prefix,pfs,0);
    huffNode *righty = new huffNode();
    h->right = righty;
    makeTree(righty,prefix,pfs,1);
    return;
}
  
