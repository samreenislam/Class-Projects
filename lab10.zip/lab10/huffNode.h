//Samreen Islam sfi6zy 4/18/17 Lab102 huffNode.h

#ifndef HUFFNODE_H
#define HUFFNODE_H

#include <iostream>

using namespace std;

class huffNode {
 public:
  huffNode();
  huffNode(char c, int f);
  ~huffNode();
  huffNode *left, *right;
  char ascii;
  int freq;
};

#endif
