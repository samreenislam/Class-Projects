

public class MainDisplay {

	public static void main(String[] args) {
		DisplayFrame game = new DisplayFrame();
		game.run();
		
	}

}

